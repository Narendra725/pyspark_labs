report_structure = {
    "chapter1" : ["Page 1","Page 2"],
    "chapter2" : ["Page 3","Page 4"]

}

jso = {
    "name" : ""
}
for k in report_structure.items():
    for v in k :
        jso["name"] = 

        print(k,v)

# sample ={}
# for k in report_structure.items():
#     sample[f"new{k[0]}"]= f"'{k[0]}'"
# print(sample)